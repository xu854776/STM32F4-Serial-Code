#include "stm32f4xx_hal.h"
#include "usbd_cdc_if.h"
#include "stdio.h"
#include "string.h"
#include "Serial.h"

int CDC_SendFeed(uint8_t* Fed, uint16_t Len);//CDC发送反馈数据的函数
int CDC_Receive(uint8_t* Buf, uint16_t Len,_controldata_chassisInfo concha,_controldata_panInfo conpan);//CDC接收控制数据的函数
void Pack_Data(_FeedBack* feedback,uint8_t* feedArray);//打包反馈的信息
void UnPack_Data_Cha(uint8_t *ConChaArray,_controldata_chassisInfo concha);//解码收到的底盘控制数据
void UnPack_Data_pan(uint8_t *ConpanArray,_controldata_panInfo conpan);//解码收到的云台控制数据

/**
* @brief  将数据包发送到上位机
  * @param
			Fed 数据包
			Len 数据包的大小--占用内存字节数（协议规定为8Bytes）
  * @retval 无
  */
int CDC_SendFeed(uint8_t* Fed, uint16_t Len)
{
	CDC_Transmit_FS(Fed, Len);
	return 0;
}

/**
  * @brief  接收上位机传入的数据包
  * @param
		Buf 指向一个_FeedBack的指针
	    Len 传入数据的长度
	    concha 底盘控制信息的结构体
	    conpan 云台控制信息的结构体
  * @retval 0  暂时没有意义
  */
int CDC_Receive(uint8_t* Buf, uint16_t Len,_controldata_chassisInfo concha,_controldata_panInfo conpan)
{
	CDC_Receive_FS(Buf, &Len);
	if(Buf[0]==0xFA)UnPack_Data_Cha(Buf, concha);
	else if(Buf[0]==0xFB)UnPack_Data_pan(Buf, conpan);
	else return -1;
	return 0;
}

/**
  * @param
		feedback 指向一个_FeedBack的指针
	    feedArray 由数据段重组的uint8类型数组
  * @retval 无
  */
void Pack_Data(_FeedBack* feedback,uint8_t* feedArray)
{	//把数组中信息封入数据包中
	feedArray[0] = 0XFF;//这是帧头
	feedArray[1] = feedback->Shoot_Mode;
	feedArray[2] = feedback->Shoot_Speed;
	feedArray[3] = feedback->Armor_Id;
	feedArray[4] = (uint8_t)(feedback->HP_Remain);
	feedArray[5] = (uint8_t)(feedback->HP_Remain >> 8);
	feedArray[6] = 0XAA;//暂时无意义
	feedArray[7] = 0XFE;//芝士帧尾
}

/**
  * @brief  将接收到的控制数组拆分为对应的结构体
  * @param
        ConChaArray 传入底盘控制数组
        concha 底盘控制信息的结构体
  * @retval 无
  */
void UnPack_Data_Cha(uint8_t *ConChaArray,_controldata_chassisInfo concha)
{
	concha->x_Speed=ConChaArray[1];
	concha->y_Speed=ConChaArray[2];
	concha->rotational_speed=ConChaArray[3];
	concha->chassis_state=ConChaArray[4];
}

/**
  * @brief  将接收到的控制数组拆分为对应的结构体
  * @param
		ConpanArray 传入云台控制数组
		conpan 云台控制数组的结构体
  * @retval 无
  */
void UnPack_Data_pan(uint8_t *ConpanArray,_controldata_panInfo conpan)
{
	conpan->pitch_angle = ConpanArray[1] | ConpanArray[2] <<8;
	conpan->yaw_angle = ConpanArray[3] | ConpanArray[4] <<8;
	conpan->shoot_mode = ConpanArray[5];
	conpan->shoot_speed = ConpanArray[6];
}
