#include "stdio.h"
#include "string.h"
#include "stdint.h"
#include "Serial.h"

void Pack_Data_Cha(_controldata_chassis* Data_Cha,uint8_t* ChaArray);//打包底盘控制数据
void Pack_Data_Pan(_controldata_pan* Data_Pan,uint8_t* PanArray);//打包云台控制数据
void Unpack_Data_Feed(uint8_t *FeedArray,_FeedBackInfo Feedback);//解码底盘反馈数据

void Pack_Data_Cha(_controldata_chassis* Data_Cha,uint8_t* ChaArray)
{
    //把数组中信息封入数据包中
	ChaArray[0] = 0XFA;//这是帧头
	ChaArray[1] = Data_Cha->x_Speed;
    ChaArray[2] = Data_Cha->y_Speed;
	ChaArray[3] = Data_Cha->rotational_speed;
    ChaArray[4] = Data_Cha->chassis_state;
    ChaArray[5] = 0XAA;//暂时无意义
	ChaArray[6] = 0XAA;
    ChaArray[7] = 0XFE;//这是帧尾
}

void Pack_Data_Pan(_controldata_pan* Data_Pan,uint8_t* PanArray)
{
    //把数组中信息封入数据包中
	PanArray[0] = 0XFB;//这是帧头
	PanArray[1] = (uint8_t)(Data_Pan->pitch_angle);
    PanArray[2] = (uint8_t)(Data_Pan->pitch_angle >> 8);
	PanArray[3] = (uint8_t)(Data_Pan->yaw_angle);
    PanArray[4] = (uint8_t)(Data_Pan->yaw_angle >> 8);
    PanArray[5] = Data_Pan->shoot_mode;
	PanArray[6] = Data_Pan->shoot_speed;
    PanArray[7] = 0XFE;//这是帧尾
}

void Unpack_Data_Feed(uint8_t *FeedArray,_FeedBackInfo Feedback)
{
    Feedback->Shoot_Mode    =   FeedArray[1];
    Feedback->Shoot_Speed   =   FeedArray[2];
    Feedback->Armor_Id      =   FeedArray[3];
    Feedback->HP_Remain     =   FeedArray[4] | FeedArray[5] <<8;
}