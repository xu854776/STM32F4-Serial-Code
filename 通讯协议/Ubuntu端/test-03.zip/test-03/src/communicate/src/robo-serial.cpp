#include "serial/serial.h"//调用串口相关头文件
#include "ros/ros.h"//在ros下使用serial包进行通讯
#include "iostream"
#include "Serial.h"

int Data_Transmit(uint8_t* Buf, uint16_t Len,_controldata_chassisInfo concha,_controldata_panInfo conpan,_FeedBackInfo fd);//发送控制数据
int Data_Receive(uint8_t* Fed, uint16_t Len,_FeedBackInfo fd);//接收反馈数据
//全局变量定义区
    serial::Serial sp;//创建一个Serial类
    serial::Timeout to = serial::Timeout::simpleTimeout(5000);//创建timeout
    uint8_t WriteArray[8]={0};
    uint8_t ReadArray[8]={0};
    uint8_t ReBuffer[8];
    uint8_t WrBuffer[8];
    
//全局变量定义区


int main(int argc,char** argv){
    setlocale(LC_CTYPE,"zh_CN.utf8");//设置中文输出
    ros::init(argc,argv,"serial_port");
    ros::NodeHandle n;//创建句柄
    // serial::Serial sp;//创建一个Serial类
    // serial::Timeout to = serial::Timeout::simpleTimeout(5000);//创建timeout
    sp.setPort("/dev/ttyACM0");//设置要打开的串口名称
    sp.setBaudrate(115200);//设置串口通信的波特率
    sp.setTimeout(to);//串口设置timeout
    try
    {
        sp.open();//尝试启动串口
    }
    catch(serial::IOException& e)
    {
        ROS_ERROR_STREAM("Unable to open port!Please check your setting!");
        return -1;
    }
    if(sp.isOpen())
    {
        ROS_INFO_STREAM("/dev/ttyACM0 is opened!");//判断是否成功开启串口
    }
    else
    {
        return -1;
    }

    //结构体初始化区
    WrBuffer[0]=0XFB;
    _FeedBackInfo fd;
    fd = (_FeedBackInfo)malloc(sizeof(FeedBack));
 	_controldata_chassisInfo chas;
    chas = (_controldata_chassisInfo)malloc(sizeof(_controldata_chassis));
    chas->x_Speed = 0X11;
    chas->y_Speed = 0x45;
    chas->rotational_speed = 0X14;
    chas->chassis_state =ROTATE;
    _controldata_panInfo pan;
    pan = (_controldata_panInfo)malloc(sizeof(_controldata_pan));
    pan->pitch_angle = 0X1919;
    pan->yaw_angle = 0X8100;
    pan->shoot_mode = SINGLE_FIRE;
    pan->shoot_speed = LOW_SPEED;
    //结构体初始化区
    ros::Rate loop_rate(500);
    while(ros::ok())
    {
        Data_Receive(ReBuffer,8,fd);
        Data_Transmit(WrBuffer,8,chas,pan,fd);
        loop_rate.sleep();
    }
    sp.close();
    return 0;
}

int Data_Transmit(uint8_t* Buf, uint16_t Len,_controldata_chassisInfo concha,_controldata_panInfo conpan,_FeedBackInfo fd)
{ 
    WriteArray[8]={0};
    if(Buf[0]==0XFA)
    {  
        for(int i=0;i<8;i++)
        WriteArray[i]={0};
        Pack_Data_Cha(concha,WriteArray);
        sp.write(WriteArray,8);
    }
    if(Buf[0]==0XFB)
    {
        for(int i=0;i<8;i++)
        WriteArray[i]={0};
        Pack_Data_Pan(conpan,WriteArray);
        sp.write(WriteArray,8);
    }
    size_t n = sp.available();//获取缓冲区内的字节数
        if(n!=0)
        {
            n = sp.read(Buf,Len);//读取数据
            Unpack_Data_Feed(ReadArray,fd);
            for(int i=0; i<Len;i++){
            std::cout<<std::hex<<(Buf[i]&0xff)<<' ';//以字符的方式打印到屏幕上
        }   std::cout<<std::endl;
        }
    else return -1;  //错误：找不到所需数据
    return 0;   //正常发送
}

int Data_Receive(uint8_t* Fed, uint16_t Len,_FeedBackInfo fd)
{
    size_t n = sp.available();//获取缓冲区内的字节数
        if(n!=0)
        {
            n = sp.read(Fed,Len);//读取数据
            Unpack_Data_Feed(ReadArray,fd);
            for(int i=0; i<Len;i++){
            std::cout<<std::hex<<(Fed[i]&0xff)<<' ';//以字符的方式打印到屏幕上
        }   std::cout<<std::endl;
        }
    return 0;
}
